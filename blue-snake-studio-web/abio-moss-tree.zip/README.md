# The Moss Man / B$S — Moss Tree

A single-file, GitHub Pages-ready portfolio for The Moss Man and Blue $nake Studio.

The interface is a nine-node angular project tree influenced by calm console navigation. It supports touch swipe, mouse wheel, arrow keys, direct selection, URL hashes, reduced motion and a print-friendly expanded résumé. Frankston → Fuji has its own bilingual sister-city song branch, Black Omen links to its Bunurong–Boonwurrung research map, and the complete OSS-734G Semantic Sovereignty field manual is included as a linked companion page.

Open `index.html` directly or serve the repository root with any static web server.
